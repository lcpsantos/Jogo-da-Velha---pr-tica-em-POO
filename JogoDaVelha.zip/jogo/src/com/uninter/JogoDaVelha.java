package com.uninter;

public class JogoDaVelha {

    public static void main(String[] args) throws InterruptedException {

        Jogo jogo = new Jogo();

    }

}